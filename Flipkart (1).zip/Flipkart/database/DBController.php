<?php

class DBController {
    protected $host = 'localhost';
    protected $user = 'root';
    protected $password = '';
    protected $database = 'flipkart_db';
    protected $port = 3307;  // Added port for MySQL connection

    public $con = null;

    public function __construct() {
        $this->con = new mysqli($this->host, $this->user, $this->password, $this->database, $this->port);
        
        if ($this->con->connect_error) {
            die("Failed to connect: " . $this->con->connect_error);
        }
        // echo "Connection Successful";
    }

    public function __destruct() {
        $this->closeConnection();
    }

    function closeConnection() {
        if ($this->con != null) {
            $this->con->close();
            $this->con = null;
        }
    }
}

// $config = new DBController();

?>
