<?php
$URL = "http://localhost/flipkart";
?>