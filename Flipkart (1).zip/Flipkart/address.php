<?php
ob_start();
include 'header.php';
// if(!isset($_SESSION['login'])){
//     header('location:login.php');
//     // echo "<script>location.href='".$URL."/login.php';</script>";
// }

?>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $orderId = $_POST['orderId'];
    $orderAmount = $_POST['orderAmount'];
}
?>

<?php
include 'partials/_address.php';
?>

<?php
include 'partials/_footer.php';
?>