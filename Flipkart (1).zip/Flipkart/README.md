PHP Deployment Guide
Follow the steps below to set up and deploy the PHP project.

Step 1: Database Setup
Open phpMyAdmin.
Create a new database.
The database name and configuration settings are available in the file:
database/DBController.php
Update the port number if needed:
The default port is 3306.
The current setup uses 3307. Change it as per your requirement.

Step 2: Import Database
Navigate to phpMyAdmin.
Import all tables using the SQL file:
database/flikart_db.sql

Step 3: Mail Setup
Create an account on MailerSend.
Verify your domain.
Generate an Integration Key.
Copy the generated key and paste it into the file:
sendotp.php

Step 4: Install Dependencies
To send emails, install Composer and the required SDKs:

Install Composer.

Run the following commands in the project directory:

composer require php-http/guzzle7-adapter nyholm/psr7
composer require mailersend/mailersend

Local Deployment Instructions
Copy all your project files to:
xampp/htdocs/ (if using XAMPP)
Complete all the setup steps mentioned above.

Visit http://localhost/your-project-folder in your browser to run the website.